<html>
    <head>
        <title>Service page</title>
        <style>
            body{
                background: linear-gradient(to top, rgba(0,0,0,0.5)50%,rgba(0,0,0,0.5)50%), url(1.jpg);
   
            }
</head>
<body>
